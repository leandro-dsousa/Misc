import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gradient-component',
  templateUrl: './gradient-component.component.html',
  styleUrls: ['./gradient-component.component.css']
})
export class GradientComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
