import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glass-component',
  templateUrl: './glass-component.component.html',
  styleUrls: ['./glass-component.component.css']
})
export class GlassComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
