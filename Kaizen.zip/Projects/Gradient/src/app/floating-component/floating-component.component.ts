import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-floating-component',
  templateUrl: './floating-component.component.html',
  styleUrls: ['./floating-component.component.css']
})
export class FloatingComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  

}
