import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sliding-highlight-hover-component',
  templateUrl: './sliding-highlight-hover-component.component.html',
  styleUrls: ['./sliding-highlight-hover-component.component.css']
})
export class SlidingHighlightHoverComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
